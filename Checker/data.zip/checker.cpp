#include "testlib.h"
#include <string>
#include <vector>
#include <cstring>
#include <algorithm>

int main(int argc, char* argv[]) {
  registerTestlibCmd(argc, argv);

  auto pans = ouf.readLine();
  ouf.readEof();

  if (pans == "No solution.") {
    auto jans = ans.readLine();
    if (jans == pans) {
      quitf(_ok, "The answer is correct.");
    } else {
      quitf(_wa, "The answer is wrong.");
    }
  }

  std::vector<int> pansArray, jansArray;
  
  int cur = 0;
  for (int i = 0; i < pans.length(); i++) {
    if (pans[i] == ' ') {
      pansArray.push_back(cur);
      cur = 0;
    } else {
      cur = cur * 10 + pans[i] - '0';
    }
  }
  if (cur != 0) {
    pansArray.push_back(cur);
  }

  auto jans = ans.readLine();

  if (!ans.eof()) {
    quitf(_wa, "The answer is too long.");
  }

  cur = 0;
  for (int i = 0; i < jans.length(); i++) {
    if (jans[i] == ' ') {
      jansArray.push_back(cur);
      cur = 0;
    } else if (!std::isdigit(jans[i])) {
      quitf(_wa, "Theanswer is wrong.");
    } else {
      cur = cur * 10 + jans[i] - '0';
    }
  }
  if (cur != 0) {
    jansArray.push_back(cur);
  }

  // quitf(_ok, "It seems to be no problems here.");

  std::sort(pansArray.begin(), pansArray.end());
  std::sort(jansArray.begin(), jansArray.end());

  if (pansArray == jansArray) {
    quitf(_ok, "The answer is correct.");
  } else {
    quitf(_wa, "The answer is wrong.");
  }

  return 0;
}